const About = () => {
    return (
        <><div className="container about-container d-flex justify-content-start align-items-center">
        <p className="fs-5">
          React aplikacija kreirana za potrebe predmeta{" "}
          <strong>
              Razvoj Veb Aplikacija
          </strong>{" "}
          na VTSNS
        </p>
      </div>
  </>
    )
}

export default About