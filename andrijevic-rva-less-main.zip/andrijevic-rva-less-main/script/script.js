const navSlide = () => {
  const toggleButton = document.querySelector(".toggle-button");
  const nav = document.querySelector(".navbar-links");

  toggleButton.addEventListener("click", () => {
    nav.classList.toggle("navbar-links-active");
  });
};

navSlide();
